import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

/*
 * Story of the Test Case
 * Verify the user is able to Add Category into Expense or Income Successfuly
*/

// Start Spending Tracker Application

Mobile.startApplication('C:\\Users\\Mahmoud Abdelhady\\Downloads\\Spending Tracker-1.6.1.apk', false)

void addCategory(String catText, String transType) {
	
	//Clicking on Categories TAB
	Mobile.tap(findTestObject('Spending Tracker/CategoriesObjects/android.widget.TextView - Categories'), 0)
	
	if(transType == 'expense') {
		//Verify that the Expense Radio Button is checked
		Mobile.verifyElementChecked(findTestObject('Spending Tracker/CategoriesObjects/android.widget.RadioButton - Expense'), 0)
		
		//Clicking on Add Icon in the top
		Mobile.tap(findTestObject('Spending Tracker/CategoriesObjects/android.widget.ImageButton - Add'), 0)
		
		//Clicking on Name textarea
		Mobile.tap(findTestObject('Spending Tracker/CategoriesObjects/android.widget.TextView - Name'), 0)
		
		//Set Text with the Category you want to add
		Mobile.setText(findTestObject('Spending Tracker/CategoriesObjects/android.widget.EditText - NameTextArea'), catText, 0)
		
		/*//Clicking on the Icon
		Mobile.tap(findTestObject('Spending Tracker/CategoriesObjects/android.widget.TextView - Icon'), 0)
		
		//Selecting an Icon
		Mobile.selectListItemByIndex(findTestObject('Spending Tracker/CategoriesObjects/android.widget.GridView'), 4, 0)*/
		
		//Clicking on Done to Save
		Mobile.tap(findTestObject('Spending Tracker/CategoriesObjects/android.widget.TextView - Done'), 0)
		
	} else if(transType == 'income') {
		//Checking on Income Radio Button
		Mobile.checkElement(findTestObject('Spending Tracker/CategoriesObjects/android.widget.RadioButton - Income'), 0)
		
		//Verify that the Income Radio Button is checked
		Mobile.verifyElementChecked(findTestObject('Spending Tracker/CategoriesObjects/android.widget.RadioButton - Income'), 0)
		
		//Clicking on Add Icon in the top
		Mobile.tap(findTestObject('Spending Tracker/CategoriesObjects/android.widget.ImageButton - Add'), 0)
		
		//Clicking on Name textarea
		Mobile.tap(findTestObject('Spending Tracker/CategoriesObjects/android.widget.TextView - Name'), 0)
		
		//Set Text with the Category you want to add
		Mobile.setText(findTestObject('Spending Tracker/CategoriesObjects/android.widget.EditText - NameTextArea'), catText, 0)
		
		/*//Clicking on the Icon
		Mobile.tap(findTestObject('Spending Tracker/CategoriesObjects/android.widget.TextView - Icon'), 0)
		
		//Selecting an Icon
		Mobile.selectListItemByIndex(findTestObject('Spending Tracker/CategoriesObjects/android.widget.GridView'), 4, 0)*/
		
		//Clicking on Done to Save
		Mobile.tap(findTestObject('Spending Tracker/CategoriesObjects/android.widget.TextView - Done'), 0)
	}
}

addCategory('Outing', 'expense')