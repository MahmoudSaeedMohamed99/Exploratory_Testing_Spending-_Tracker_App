import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable

import org.openqa.selenium.By
import org.openqa.selenium.Keys as Keys
import io.appium.java_client.AppiumDriver as AppiumDriver
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory as MobileDriverFactory

/*
 * Story of the Test Case
 * Verify that the user is not able to Delete Default Account
*/

// Start Spending Tracker Application
Mobile.startApplication('C:\\Users\\Mahmoud Abdelhady\\Downloads\\Spending Tracker-1.6.1.apk', false)

//Clicking on Accounts TAB
Mobile.tap(findTestObject('Spending Tracker/AccountsObjects/android.widget.TextView - Accounts'), 0)

//Tap and Hold on the Account
Mobile.tapAndHold(findTestObject('Spending Tracker/AccountsObjects/android.widget.LinearLayout'), 1, 0)

//Tap on Delete Icon
Mobile.tap(findTestObject('Spending Tracker/AccountsObjects/android.widget.TextView - DeleteIcon'), 0)

//Get the Error Message
String error = Mobile.getText(findTestObject('Spending Tracker/AccountsObjects/android.widget.TextView - ErrorMsg'), 0)

//Verify the Error Message
Mobile.verifyEqual(error, "'Personal' is the 'Default' Account. It cannot be deleted.")

//Close the Error Message
Mobile.tap(findTestObject('Spending Tracker/AccountsObjects/android.widget.Button - Close'), 0)
	