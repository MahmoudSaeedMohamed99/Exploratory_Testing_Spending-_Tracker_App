import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

/*
 * Story of the Test Case
 * Verify the user is able to Edit Transaction
*/

// Start Spending Tracker Application

Mobile.startApplication('C:\\Users\\Mahmoud Abdelhady\\Downloads\\Spending Tracker-1.6.1.apk', false)

// Edit the Transaction from Income to Expense or vice versa

void editTransToExpenseOrIncome(String transType) {
	
	//Clicking on Transactions TAB
	Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.TextView - Transactions'), 0)
	
	//Clicking on Transaction to edit it
	Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RelativeLayout'), 0)
	
	if(transType == 'expense') {
		
		//Checking on Expense Radio Button
		Mobile.checkElement(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RadioButton - Expense'), 0)
		
		//Verify that Expense Radio Button has been checked
		Mobile.verifyElementChecked(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RadioButton - Expense'), 0)
		
		//Clicking on Done
		Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.TextView - Done'), 0)
		
	} else if(transType == 'income') {
		
		//Checking on Income Radio Button
		Mobile.checkElement(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RadioButton - Income'), 0)
		
		//Verify that Income Radio Button has been checked
		Mobile.verifyElementChecked(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RadioButton - Income'), 0)
		
		//Clicking on Done
		Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.TextView - Done'), 0)
	}
	
}

void editTransCategory(String cat, String transType) {
	
	//Clicking on Transactions TAB
	Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.TextView - Transactions'), 0)
	
	//Clicking on Transaction to edit it
	Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RelativeLayout'), 0)
	
	if(transType == 'expense') {
		//Verify that the Expense Radio Button is checked
		Mobile.verifyElementChecked(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RadioButton - Expense'), 0)
		
		//Selecting new Category from Categories List
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Category'), 0)
		Mobile.selectListItemByLabel(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.ListView'), cat, 0)
		
		//Clicking on Done to save
		Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.TextView - Done'), 0)
		
	} else if(transType == 'income') {
		//Verify that the Expense Radio Button is checked
		Mobile.verifyElementChecked(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RadioButton - Income'), 0)
		
		//Clicking on Category
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Category'), 0)
		
		//Clicking on Search Bar
		Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.EditText - SearchArea'), 0)
		
		//Writing the Category
		Mobile.setText(findTestObject('Spending Tracker/TransactionsObjects/android.widget.EditText - SearchArea'), cat, 0)
		
		//Selecting the Category
		Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.LinearLayout - SearchResult'), 0)
		
		//Clicking on Done to save
		Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.TextView - Done'), 0)
	}
	
}

void editTransAmount(String amount, String transType) {
	
	//Clicking on Transactions TAB
	Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.TextView - Transactions'), 0)
	
	//Clicking on Transaction to edit it
	Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RelativeLayout'), 0)
	
	if(transType == 'expense') {
		//Verify that the Expense Radio Button is checked
		Mobile.verifyElementChecked(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RadioButton - Expense'), 0)
		
		//Clicking on Amount
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Amount'), 0)
		Mobile.clearText(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Amount'), 0)
		
		//Writing the new Amount
		Mobile.setText(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.EditText'), amount, 0)
		Mobile.hideKeyboard()
		
		//Clicking on Done to save
		Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.TextView - Done'), 0)
		
	} else if(transType == 'income') {
		//Verify that the Expense Radio Button is checked
		Mobile.verifyElementChecked(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RadioButton - Income'), 0)
		
		//Clicking on Amount
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Amount'), 0)
		Mobile.clearText(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Amount'), 0)
		
		//Writing the new Amount
		Mobile.setText(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.EditText'), amount, 0)
		Mobile.hideKeyboard()
		
		//Clicking on Done to save
		Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.TextView - Done'), 0)
	}
	
}


//editTransToExpenseOrIncome('income')

//editTransCategory('Fuel', 'income')

editTransAmount('400', 'expense')