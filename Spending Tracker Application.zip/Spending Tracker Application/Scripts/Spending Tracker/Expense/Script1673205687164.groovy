import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.configuration.RunConfiguration as RunConfiguration
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.util.internal.PathUtil as PathUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint

/*
 * Story of the Test Case 
 * Verify the user is able to Add Expense Successfuly
*/

// Start Spending Tracker Application

Mobile.startApplication('C:\\Users\\Mahmoud Abdelhady\\Downloads\\Spending Tracker-1.6.1.apk', false)

/*
 * After starting the Application
 * Click on Expense Button in the bottom
*/

Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Button -  Expense'), 0)

/*
 * Click on Category Button
 * A ListView is opened
 * Choose a Category
*/

Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Category'), 0)
Mobile.selectListItemByLabel(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.ListView'), 'Clothes', 0)

/*
 * Click on Amount TextField 
 * Enter the Amount
*/

Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Amount'), 0)
Mobile.setText(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.EditText'), '1000', 0)
Mobile.hideKeyboard()

/*
 * (IT'S OPTIONAL)
 * Swicth on Repeating Details
 * Click on Every Text View
 * Choose Number of Weeks , Moths or Days to repeat
 * Click on Set Button
 * Click on End Date
 * Enter a Deadline for repeating
 * Click on Set Button
 * Click on Note and Enter a Note to your Expense
*/

Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Switch - OFF'), 0)
Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - 1 Month'), 0)
Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - 1'), 0)
Mobile.selectListItemByLabel(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.ListView (1)'), '2', 0)
Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Month(s)'), 0)
Mobile.selectListItemByLabel(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.ListView (2)'), 'Week(s)', 0)
Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Button - Set'), 0)
Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - End Date'), 0)
Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Button - Set'), 0)
Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - No Note Entered'), 0)
Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.EditText - Create Note'), 0)
Mobile.setText(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.EditText - Create Note'), 'AnyThing' , 0)
Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Button - Set'), 0)

/*
 * After entering all the data into Expense Field
 * Click on Done Button in the top right
*/

Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Done'), 0)