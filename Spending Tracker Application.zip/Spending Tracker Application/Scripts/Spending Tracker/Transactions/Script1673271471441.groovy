import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.configuration.RunConfiguration as RunConfiguration
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.util.internal.PathUtil as PathUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint

/*
 * Story of the Test Case
 * Verify the user is able to Add Expense or Income from Transactions TAB Successfuly
*/

// Start Spending Tracker Application

Mobile.startApplication('C:\\Users\\Mahmoud Abdelhady\\Downloads\\Spending Tracker-1.6.1.apk', false)

/*
 * This is Method to add an Expense or Income from Transaction TAB 
 * Contains Expense and Income Field as a parameters
 * Then checking if the Transaction type is Expense or Income to add it to the right place
 * This is checking based on transType parameter [Expense or Income]
 * */

void addTransaction(String category, int amount, int numOfRepeating, String every, String note, String transType) {
	
	//Clicking on Transactions TAB
	Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.TextView - Transactions'), 0)
	
	//Clicking on Add Icon in the top
	Mobile.tap(findTestObject('Spending Tracker/TransactionsObjects/android.widget.ImageButton - Add'), 0)
	
	if(transType == 'expense') {
		
		//Verify that Expense Radio Button is checked
		Mobile.verifyElementChecked(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RadioButton - Expense'), 0)
		
		//Selecting Category
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Category'), 0)
		Mobile.selectListItemByLabel(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.ListView'), category, 0)
		
		//Entering Amount
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Amount'), 0)
		Mobile.setText(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.EditText'), amount.toString(), 0)
		Mobile.hideKeyboard()
		
		//Entering Repeating Details
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Switch - OFF'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - 1 Month'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - 1'), 0)
		Mobile.selectListItemByLabel(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.ListView (1)'), numOfRepeating.toString(), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Month(s)'), 0)
		Mobile.selectListItemByLabel(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.ListView (2)'), every, 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Button - Set'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - End Date'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Button - Set'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - No Note Entered'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.EditText - Create Note'), 0)
		Mobile.setText(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.EditText - Create Note'), note , 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Button - Set'), 0)
		
		//Clicking on Done button to Save
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Done'), 0)
		
	}else if(transType == 'income') {
		
		//Checking Income Radio Button
		Mobile.checkElement(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RadioButton - Income'), 0)
		
		//Verify that Income Radio Button is checked
		Mobile.verifyElementChecked(findTestObject('Spending Tracker/TransactionsObjects/android.widget.RadioButton - Income'), 0)
		
		//Selecting Category
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Category'), 0)
		Mobile.selectListItemByLabel(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.ListView'), category, 0)
		
		//Entering Amount
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Amount'), 0)
		Mobile.setText(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.EditText'), amount.toString(), 0)
		Mobile.hideKeyboard()
		
		//Entering Repeating Details
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Switch - OFF'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - 1 Month'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - 1'), 0)
		Mobile.selectListItemByLabel(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.ListView (1)'), numOfRepeating.toString(), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Month(s)'), 0)
		Mobile.selectListItemByLabel(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.ListView (2)'), every, 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Button - Set'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - End Date'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Button - Set'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - No Note Entered'), 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.EditText - Create Note'), 0)
		Mobile.setText(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.EditText - Create Note'), note , 0)
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.Button - Set'), 0)
		
		//Clicking on Done button to Save
		Mobile.tap(findTestObject('Spending Tracker/ExpenseAndIncomeObjects/android.widget.TextView - Done'), 0)
	}
	
}

/*
 * Calling addTransaction Method
 * Give it the required parameters
 * Notice that the Category parameter is different in Income and Expense , It's only Salary Category in Income Categories 
*/

addTransaction('Salary', 3000, 3, 'Day(s)','Anything', 'income')