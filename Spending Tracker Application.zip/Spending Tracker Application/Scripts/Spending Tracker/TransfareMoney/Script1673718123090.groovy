import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import io.appium.java_client.AppiumDriver as AppiumDriver
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory as MobileDriverFactory

/*
 * Story of the Test Case
 * Verify the user is able to transfer Money to another Account Successfuly
*/

// Start Spending Tracker Application

Mobile.startApplication('C:\\Users\\Mahmoud Abdelhady\\Downloads\\Spending Tracker-1.6.1.apk', false)

void transferMoney(String amount, String from, String to) {
	
	//Initializing Appium Driver
	AppiumDriver<?> driver = MobileDriverFactory.getDriver();
	
	//Clicking on Accounts TAB
	Mobile.tap(findTestObject('Spending Tracker/AccountsObjects/android.widget.TextView - Accounts'), 0)
	
	//Clicking on Transfer Button
	Mobile.tap(findTestObject('Spending Tracker/AccountsObjects/android.widget.Button - Transfer'), 0)
	
	//Clicking on Amount and Enter the Amount you want
	Mobile.tap(findTestObject('Spending Tracker/AccountsObjects/android.widget.TextView - Amount'), 0)
	Mobile.setText(findTestObject('Spending Tracker/AccountsObjects/android.widget.EditText'), amount, 0)
	Mobile.hideKeyboard()
	
	//Selecting the account that you want to send from it
	Mobile.tap(findTestObject('Spending Tracker/AccountsObjects/android.widget.TextView - From'), 0)
	Mobile.selectListItemByLabel(findTestObject('Spending Tracker/AccountsObjects/android.widget.ListView'), from, 0)
	
	//Selecting the account that you want to send to it
	Mobile.tap(findTestObject('Spending Tracker/AccountsObjects/android.widget.TextView - To'), 0)
	Mobile.selectListItemByLabel(findTestObject('Spending Tracker/AccountsObjects/android.widget.ListView'), to, 0)
	
	//Clicking on Done
	Mobile.tap(findTestObject('Spending Tracker/AccountsObjects/android.widget.TextView - Done'), 0)
	
	//Clicking on Transactions TAB
	Mobile.tap(findTestObject('Spending Tracker/AccountsObjects/android.widget.TextView - Transactions'), 0)
	
	//Get Transactions from ListView
	List<WebElement> elements = driver.findElementsByClassName('Spending Tracker/AccountsObjects/android.widget.ListView - Transactions')
	
	//Looping on the Transactions
	for(WebElement trans : elements) {
		
		String actualTrans = trans.getText()
		
		//Verify that the transfer is done
		Mobile.verifyEqual(actualTrans, 'Transfer')
		break
	}
	
}

transferMoney('100', 'Personal', 'mahmoud')